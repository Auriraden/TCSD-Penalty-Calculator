'use client';

import { useState, useMemo } from 'react';
import { Search, Copy, Check, X, DollarSign, Clock, Users, Scale, BookOpen, Calculator } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ThemeToggle } from '@/components/theme-toggle';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Charge {
  id: string;
  name: string;
  fine: number;
  jailTime: number;
  pcCode: string;
  subtitle: string;
  class: string;
  description: string;
}

const mockCharges: Charge[] = [
  // Title 1: Crimes Against the Sovereignty of the State
  { id: '1', name: 'Sabotage', pcCode: 'PC 000.05', subtitle: 'Sabotage', class: 'Felony', fine: 30000, jailTime: 38, description: 'Deliberate damage or destruction of goverment property or operations.' },
  { id: '2', name: 'Rebellion', pcCode: 'PC 000.06', subtitle: 'Rebellion', class: 'Felony', fine: 32000, jailTime: 40, description: 'Organized violent resistance against the state\'s authority.' },
  { id: '3', name: 'Attempted Destruction of Public Property', pcCode: 'PC 000.12', subtitle: 'Attempted Destruction of Public Property', class: 'Felony', fine: 25000, jailTime: 34, description: 'Attempted but failing to damage or destroy government property.' },
  { id: '4', name: 'Terrorism', pcCode: 'PC 11410', subtitle: 'Terrorism', class: 'Felony', fine: 33000, jailTime: 40, description: 'Using violence or threats to create fear and disrupt government society.' },
  { id: '5', name: 'Perjury', pcCode: 'PC 118', subtitle: 'Perjury', class: 'Felony', fine: 27000, jailTime: 35, description: 'Knowingly lying or making false statements under oath in court.' },
  { id: '6', name: 'Contempt of Court', pcCode: 'PC 166', subtitle: 'Contempt of Court', class: 'Judicial Discretion', fine: 0, jailTime: 0, description: 'Disrespecting or disobeying court orders or interfering with judicial proceedings.' },
  { id: '7', name: 'Insurrection', pcCode: 'PC 2383', subtitle: 'Insurrection', class: 'Felony', fine: 30000, jailTime: 38, description: 'Uprising or revolt against the lawful authority of the government.' },
  { id: '8', name: 'Sedition', pcCode: 'PC 2384', subtitle: 'Sedition', class: 'Felony', fine: 32000, jailTime: 40, description: 'Inciting rebellion or resistance against lawful government authority.' },
  { id: '9', name: 'Treason', pcCode: 'PC 37(a)', subtitle: 'Treason', class: 'Felony', fine: 35000, jailTime: 40, description: 'Any person who levies war against the state of San Andreas or adheres to its enemies, giving them and comfort.' },
  { id: '10', name: 'Misprision of Treason', pcCode: 'PC 38', subtitle: 'Misprision of Treason', class: 'Felony', fine: 28000, jailTime: 36, description: 'Every person having knowledge of the commission of treason. who conceals the same, and does not, as soon may be, disclose the same to the Governor or to a judge.' },
  { id: '11', name: 'Economic Crimes against the State', pcCode: 'PC 424', subtitle: 'Economic Crimes against the State', class: 'Felony', fine: 30000, jailTime: 38, description: 'Large-scale fraud or financial crimes that threaten state integrity.' },
  { id: '12', name: 'Cyberterrorism', pcCode: 'PC 502', subtitle: 'Cyberterrorism', class: 'Felony', fine: 28000, jailTime: 34, description: 'Using computer systems to disrupt government functions or infrastructure.' },
  { id: '13', name: 'Espionage', pcCode: 'PC 792-798', subtitle: 'Espionage', class: 'Felony', fine: 35000, jailTime: 40, description: 'Illegally obtaining or transmitting government secrets to unauthorized parties.' },
  
  // Title 2: Crimes By and Against a Public Servant
  { id: '14', name: 'Bribing an Executive Officer', pcCode: 'PC 67', subtitle: 'Bribing an Executive Officer', class: 'Misdemeanor', fine: 13000, jailTime: 20, description: 'The willful offering, giving, or promising of money, favors, or benefits to an executive officer with intent to influence their official actions or decisions.' },
  { id: '15', name: 'Bribing a Ministerial Officer', pcCode: 'PC 67.5', subtitle: 'Bribing a Miniterial Officer', class: 'Misdemeanor', fine: 11000, jailTime: 15, description: 'The unlawful provision of bribes to a ministerial officer (e.g., clerks, administrative staff) to corruptly sway the execution of their non-discretionary duties.' },
  { id: '16', name: 'Resisting or Deterring an Executive Officer with Threats or Violence', pcCode: 'PC 69', subtitle: 'Resisting or Deterring an Executive Officer with Threats or Violence', class: 'Misdemeanor', fine: 14000, jailTime: 25, description: 'The use of threats, physical force, or intimidation to obstruct, resist, or deter an executive officer from performing lawful duties.' },
  { id: '17', name: 'Accepting Unauthorized Gratuities as Public Official', pcCode: 'PC 70', subtitle: 'Accepting Unathorized Gratuities as Public Official', class: 'Misdemeanor', fine: 10000, jailTime: 12, description: 'The knowing acceptance of gifts, payments, or benefits by a public official for actions within their official capacity, where such exchanges are prohibited by law.' },
  { id: '18', name: 'Presenting False or Fraudulent Claims', pcCode: 'PC 72', subtitle: 'Presenting False or Fraudelent Claims', class: 'Felony', fine: 25000, jailTime: 34, description: 'The submission of forged, falsified, or materially misleading claims to a government agency for financial gain or unwarranted benefits.' },
  { id: '19', name: 'Fraudulent Claims for Political Function Reimbursement', pcCode: 'PC 72.5', subtitle: 'Fraudulent Claims for Political Function Reimbursement', class: 'Misdemeanor', fine: 9500, jailTime: 14, description: 'The deceptive filing of expense claims related to political functions to obtain unauthorized reimbursements.' },
  { id: '20', name: 'Public Officials Appointing for Personal Gain', pcCode: 'PC 74', subtitle: 'Public Officials Appointing for Personal Gain', class: 'Felony', fine: 28000, jailTime: 35, description: 'The abuse of authority by a public official to appoint individuals to positions based on personal gain, nepotism, or quid pro quo arrangements.' },
  { id: '21', name: 'Threatening Public Officials', pcCode: 'PC 76', subtitle: 'Threatening Public Officials', class: 'Misdemeanor', fine: 12000, jailTime: 16, description: 'The intentional communication of threats to harm, intimidate, or retaliates against a public official in connection with their official duties.' },
  { id: '22', name: 'Offering a Bribe for a Public Office Appointment', pcCode: 'PC 86', subtitle: 'Offering a Bribe for a Public Office Appointment', class: 'Misdemeanor', fine: 9000, jailTime: 11, description: 'The corrupt proposal of money, favors, or advantages to secure an appointment to a public office or position.' },
  { id: '23', name: 'Accepting Payment for Performing Civil Marriages', pcCode: 'PC 94.5', subtitle: 'Accepting Payment for Performing Civil Marriages', class: 'Misdemeanor', fine: 8500, jailTime: 10, description: 'The unlawful receipt of compensation by a public official for solemnizing marriages, beyond legally authorized fees.' },
  
  // Title 3: Crimes Against Public Justice
  { id: '24', name: 'Insider Trading', pcCode: 'CC 25400', subtitle: 'Insider Trading', class: 'Felony', fine: 28500, jailTime: 31, description: 'The illegal trading of stocks, securities, or assets based on material non-public information in regard to the 911 system.' },
  { id: '25', name: 'Fraudulent Tax Filing', pcCode: 'PC 107', subtitle: 'Fraudulent Tax Filing', class: 'Felony', fine: 28500, jailTime: 31, description: 'The submission of falisfied tax returns, inflated deductions, or fictitious dependents to reduce tax liability.' },
  { id: '26', name: 'Intellectual Property Theft', pcCode: 'PC 109', subtitle: 'Intellectual Property Theft', class: 'Felony', fine: 28500, jailTime: 31, description: 'The unathorized use, reproduction, or distribution of copyrighted, patented, or trademarked material for financial gain.' },
  { id: '27', name: 'Obstruction of Justice', pcCode: 'PC 31', subtitle: 'Obstruction of Justice', class: 'Felony', fine: 33500, jailTime: 38, description: 'The unlawful interference with law enforcement, judicial proceedings, or investigations trhough acts such as destroying evidence, intimidating witnesses, or providing false information to authorities.' },
  { id: '28', name: 'Scam', pcCode: 'PC 115', subtitle: 'Scam', class: 'Misdemeanor', fine: 15000, jailTime: 30, description: 'The execution of deceptive schemes (e.g., phishing, pyramid schemes, fake charities) to unlawfully obtain money or property.' },
  { id: '29', name: 'Fraud', pcCode: 'PC 484', subtitle: 'Fraud', class: 'Felony', fine: 30000, jailTime: 35, description: 'A person who\'s activity relies on deception in order to achieve a gain.' },
  { id: '30', name: 'Illegal Financial Transactions', pcCode: 'PC 136.1', subtitle: 'Illegal Financial Transactions', class: 'Felony', fine: 28500, jailTime: 31, description: 'The deliberate execution of unregulated monetary exchanges, money laundering, or structuing transactions to evade legal reporting requirements (e.g., large cash transfers, offshore accounts).' },
  { id: '31', name: 'Securities Fraud', pcCode: 'PC 182', subtitle: 'Securities Fraud', class: 'Felony', fine: 28500, jailTime: 31, description: 'The manipulation of financial markets, misrepresentation of corporate information or Ponzi schemes to defraud investors.' },
  { id: '32', name: 'Money Laundering', pcCode: 'PC 165', subtitle: 'Money Laundering', class: 'Felony', fine: 30000, jailTime: 36, description: 'Any person who conducts or attempts to conduct a transaction with the intent to conceal illegally gained funds, in an effort to "clean" the money. The state must prove guilt and intent to charge.' },
  { id: '33', name: 'Forging, Stealing, Mutilating, and Falsifying Public Records and Documents', pcCode: 'PC 653', subtitle: 'Forging, Stealing, Mutliating, and Falsifying Public Records and Documents', class: 'Felony', fine: 30000, jailTime: 35, description: 'Anyone who knowingly creates or offers a fake document to be filed, registered, or recorded in any public office in San Andreas, and if the document were real, it could be filed or recorded under state or federal law.' },
  { id: '34', name: 'Resisting Arrest', pcCode: 'PC 530.5', subtitle: 'Resisting Arrest', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'It is illegal to willfully resist, delay, or obstruct a public official while they are performing official duties.' },
  { id: '35', name: 'Investment Fraud', pcCode: 'PC', subtitle: 'Investment Fraud', class: 'Felony', fine: 28500, jailTime: 31, description: 'Deceptive practices to solicit investments through false statements, Ponzi schemes, or concealment of material risks, resulting in financial harm to investors.' },
  { id: '36', name: 'Racketeering', pcCode: 'PC', subtitle: 'Racketeering', class: 'Felony', fine: 30000, jailTime: 35, description: 'A pattern of criminal activity that incldues murder, kindapping, robbery, bribery, extortion, and arson in a way to obtain illegal profits.' },
  { id: '37', name: 'Unauthorized Access to Financial Data', pcCode: 'PC 470', subtitle: 'Unauthorized Access to Financial Data', class: 'Felony', fine: 28500, jailTime: 31, description: 'The intentional hacking, phishing, or unawlful intrusion into financial systems, databases, or records to obtain sensitive information (e.g. bank accounts, credit card data).' },
  { id: '38', name: 'Impersonating a Government Official', pcCode: 'PC 487', subtitle: 'Impersonating a Government Official', class: 'Felony', fine: 35000, jailTime: 40, description: 'The fraudulent representation of oneself as a public officer, employee, or agent with intent to deceive, gain undue advantages or commit further criminal acts.' },
  { id: '39', name: 'Misuse of 911', pcCode: 'PC 25401', subtitle: 'Misuse of 911', class: 'Infraction', fine: 8000, jailTime: 0, description: 'A person who willingly and of their own knowledge activates, obstructs, or falsifies information in regard to the 911 system.' },
  { id: '40', name: 'Identity Theft', pcCode: 'PC 19705', subtitle: 'Identity Theft', class: 'Felony', fine: 30000, jailTime: 35, description: 'The unlawful acquisition and use of another person\'s personal or financial information to commit fraud, theft, or impersonation.' },
  { id: '41', name: 'Conspiracy', pcCode: 'PC 484', subtitle: 'Conspiracy', class: 'Felony', fine: 28500, jailTime: 31, description: 'An agreement between two or more people to commit a crime, often coupled with an overt act in furtherance of the conspiracy. It focuses on the planning stage rather than the completed act.' },
  { id: '42', name: 'Embezzlement', pcCode: 'PC 350', subtitle: 'Embezzlement', class: 'Felony', fine: 28500, jailTime: 31, description: 'The theft of money or assets that was entrusted in good faith by someone with criminal intent.' },
  { id: '43', name: 'Anti-Mask and Disguise Law', pcCode: 'PC 186.1', subtitle: 'Anti-Mask and Disguise Law', class: 'Misdemeanor', fine: 85000, jailTime: 15, description: 'Any person to wear a mask, false whiskers, or any personal disguise to evade or escape discovery, recognition, or identification in the commission of a crime. Or to escape or conceal themselves when charged with, arrested for, or convicted of any crime.' },
  { id: '44', name: 'Corporate Espionage', pcCode: 'PC 424', subtitle: 'Corporate Espionage', class: 'Felony', fine: 28500, jailTime: 31, description: 'The unauthorized acquisition, theft, or distribution of trade secrets, proprietary data, or confidential business information to gain a competitive advantage.' },
  { id: '45', name: 'Bank Fraud', pcCode: 'PC 532', subtitle: 'Bank Fraud', class: 'Felony', fine: 28500, jailTime: 31, description: 'The use of deceit, false statements, or fradulent schemes to obtain funds, assets, credit from a financial institution.' },
  { id: '46', name: 'Aiding and Abetting', pcCode: 'PC 502(c)', subtitle: 'Aiding and Abetting', class: 'Felony', fine: 35000, jailTime: 40, description: 'An act of assisting or encourageing another person in committing a crime.' },
  { id: '47', name: 'Street Terrorism', pcCode: 'PC 1090', subtitle: 'Street Terrorism', class: 'Felony', fine: 35000, jailTime: 40, description: 'A person who actively participates in a criminal street gang with knowledge that its members engage in, or have engaged in, a pattern of criminal gang activity, and who willfully promotes, furthers, or assists in felonious criminal conduct by members of that gang.' },
  { id: '48', name: 'Misappropriation of Funds', pcCode: 'PC 499c', subtitle: 'Misappropriation of Funds', class: 'Misdemeanor', fine: 13000, jailTime: 25, description: 'The unlawful diversion or unauthorized use of funds entrusted to an individual or entity (e.g., embezzlement, misuse of public/private funds) for personal gain or unauthorized purposes.' },
  { id: '49', name: 'Corruption', pcCode: 'PC 1092', subtitle: 'Corruption', class: 'Felony', fine: 35000, jailTime: 40, description: 'Any public servant who willingly accepts a bribe, fails to adhere to their duties, or refuses to complete their duties.' },
  { id: '50', name: 'Rescues', pcCode: 'PC 186', subtitle: 'Rescues', class: 'Felony', fine: 35000, jailTime: 40, description: 'Every person who rescues or atempts to rescue, or aids another in rescuing or attempting to rescue, any prisoner from lawful custody.' },
  { id: '51', name: 'Escaping', pcCode: 'PC 186.6', subtitle: 'Escaping', class: 'Felony', fine: 35000, jailTime: 40, description: 'Every suspect who escapes or attempts to escape from custody, including jail or detention facilities.' },
  { id: '52', name: 'Financial Mismanagement', pcCode: 'PC 186.1', subtitle: 'Financial Mismanagement', class: 'Felony', fine: 28500, jailTime: 31, description: 'Gross negligence or intentioanl mishandling of funds, budgest, or assets by corporate officers or trustees, leading to significant financial loss or organization harm.' },
  { id: '53', name: 'Impersonating a Peace Officer', pcCode: 'PC 503', subtitle: 'Impersonating a Peace Officer', class: 'Felony', fine: 35000, jailTime: 40, description: 'Falsely impersonating a peace officer such as a police officer, sheriff, highway patrol officer, or to possess or display law enforcement identification or uniforms with the intent to deceive.' },
  { id: '54', name: 'Aiding Escape', pcCode: 'PC 186.2', subtitle: 'Aiding Escape', class: 'Felony', fine: 35000, jailTime: 40, description: 'Every person who assists a prisoner in escaping or attempting to escape from lawful custody or confinement.' },
  { id: '55', name: 'Intimidation', pcCode: 'PC 185', subtitle: 'Intimidation', class: 'Felony', fine: 35000, jailTime: 40, description: 'A person intimidates or threatens a victim or witness with malice.' },
  { id: '56', name: 'Kickbacks', pcCode: 'PC 148(a)(1)', subtitle: 'Kickbacks', class: 'Felony', fine: 30000, jailTime: 35, description: 'Accepting bribes or illegal payments in return for favorable treatment or services.' },
  { id: '57', name: 'Counterfeiting', pcCode: 'PC 148', subtitle: 'Counterfeiting', class: 'Felony', fine: 28500, jailTime: 31, description: 'The production, distribution, or possession of forged currency, documents, or braded goods with intent to deceive.' },
  { id: '58', name: 'Criminal Profiteering', pcCode: 'PC 146(a)', subtitle: 'Criminal Profiteering', class: 'Felony', fine: 28500, jailTime: 31, description: 'An individual or organization who, through illegal activities, generates illega lprofits.' },
  { id: '59', name: 'Tax Evasion', pcCode: 'PC 538d', subtitle: 'Tax Evasion', class: 'Felony', fine: 28500, jailTime: 31, description: 'The deliberate underreporting of income, falsification of deductions, or concealment of assets to avoid tax obligations.' },
  
  // Title 4: Crimes Against a Person
  { id: '60', name: 'Gang Related Crimes', pcCode: 'PC 186.22', subtitle: 'Gang Related Crimes', class: 'Felony', fine: 30000, jailTime: 38, description: 'Enhancement for crimes committed to benefit a criminal street gang.' },
  { id: '61', name: 'Murder', pcCode: 'PC 187', subtitle: 'Murder', class: 'Felony', fine: 35000, jailTime: 40, description: 'The unlawful killing of a human being with malice aforethought (premeditation or inherent recklessness)' },
  { id: '62', name: 'Attempted Murder', pcCode: 'PC 187', subtitle: 'Attempted Murder', class: 'Felony', fine: 30000, jailTime: 36, description: 'The deliberate but unsuccessful attempt to kill another person with express malice.' },
  { id: '63', name: 'Manslaughter', pcCode: 'PC 192', subtitle: 'Manslaughter', class: 'Felony', fine: 27000, jailTime: 34, description: 'The unlawful killing of another without malice, categorized as voluntary (heat of passion) or involuntary (criminal negligence).' },
  { id: '64', name: 'Vehicular Manslaughter', pcCode: 'PC 192(c)', subtitle: 'Vehicular Manslaughter', class: 'Felony', fine: 25000, jailTime: 32, description: 'Causing death while driving unlawfully.' },
  { id: '65', name: 'Mayhem', pcCode: 'PC 203', subtitle: 'Mayhem', class: 'Felony', fine: 26000, jailTime: 33, description: 'Intentional disfigurement or deprivation of a limb, eye, or other body part.' },
  { id: '66', name: 'Torture', pcCode: 'PC 206', subtitle: 'Torture', class: 'Felony', fine: 27500, jailTime: 38, description: 'Inflicting extreme physical pain with intent to cause cruel suffering.' },
  { id: '67', name: 'Kidnapping', pcCode: 'PC 207', subtitle: 'Kidnapping', class: 'Felony', fine: 32000, jailTime: 40, description: 'Forcibly moving another person a substantial distance without consent.' },
  { id: '68', name: 'Robbery', pcCode: 'PC 211', subtitle: 'Robbery', class: 'Felony', fine: 25600, jailTime: 33, description: 'Taking property from another by force or fear, with intent to permanently deprive.' },
  { id: '69', name: 'Carjacking', pcCode: 'PC 215', subtitle: 'Carjacking', class: 'Felony', fine: 25000, jailTime: 34, description: 'Taking a motor vehicle from another by force or fear, with intent to permanently deprive.' },
  { id: '70', name: 'Possession of a Switchblade', pcCode: 'PC 21510', subtitle: 'Possession of a Switchblade', class: 'Misdemeanor', fine: 9500, jailTime: 15, description: 'Carrying a swithcblade knife with a blade longer than 2 inches.' },
  { id: '71', name: 'Assault on a Public Servant', pcCode: 'PC 217.1', subtitle: 'Assault on a Public Servant', class: 'Felony', fine: 22000, jailTime: 31, description: 'Assault against a pulbic official engaged in duties.' },
  { id: '72', name: 'False Imprisonment', pcCode: 'PC 236', subtitle: 'False Imprisonment', class: 'Felony', fine: 23000, jailTime: 32, description: 'Unlawful restraint or confinement of a person against their will.' },
  { id: '73', name: 'Human Trafficking', pcCode: 'PC 236.1', subtitle: 'Human Trafficking', class: 'Felony', fine: 35000, jailTime: 40, description: 'Recruiting, harboring, or exploiting persons through force, fraud, or coercion.' },
  { id: '74', name: 'Assault', pcCode: 'PC 240', subtitle: 'Assault', class: 'Misdemeanor', fine: 10000, jailTime: 12, description: 'An unlawful attempt to violently injure another person, coupled with present ability.' },
  { id: '75', name: 'Battery', pcCode: 'PC 242', subtitle: 'Battery', class: 'Felony', fine: 18000, jailTime: 31, description: 'The wullful and unlawful use of force or violence against another person.' },
  { id: '76', name: 'Battery of a Public Servant', pcCode: 'PC 242(a)', subtitle: 'Battery of a Public Servant', class: 'Felony', fine: 20000, jailTime: 33, description: 'The wullfull or unlawful use of force or violence against a peace officer, firefighter, EMT, or other public servant engaged in the performance of their duties.' },
  { id: '77', name: 'Battery on a Peace Officer', pcCode: 'PC 243 (b) & (c)', subtitle: 'Battery on a Peace Officer', class: 'Felony', fine: 22000, jailTime: 34, description: 'Battery against a peace officer, firefighter, or EMT engaged in duties.' },
  { id: '78', name: 'Sexual Battery', pcCode: 'PC 243.4', subtitle: 'Sexual Battery', class: 'Felony', fine: 28000, jailTime: 38, description: 'Non-consensual sexual touching of another person\'s intimate parts.' },
  { id: '79', name: 'Aggravated Assault', pcCode: 'PC 245', subtitle: 'Aggravated Assault', class: 'Felony', fine: 21000, jailTime: 32, description: 'Assault committed with a deadly weapon or force likely to cause great bodily injury.' },
  { id: '80', name: 'Discharge of a Firearm', pcCode: 'PC 246.3', subtitle: 'Discharge of a Firearm', class: 'Felony', fine: 23000, jailTime: 33, description: 'Grossly negligent discharge of a firearm in a manner endagering others.' },
  { id: '81', name: 'Negligent Discharge of a Firearm', pcCode: 'PC 246.4', subtitle: 'Negligent Discharge of a Firearm', class: 'Felony', fine: 19000, jailTime: 31, description: 'Accidental discharge causing injury or property damage due to recklessness.' },
  { id: '82', name: 'Unlawful Possession of a Firearm', pcCode: 'PC 25850', subtitle: 'Unlawful Possession of a Firearm', class: 'Felony', fine: 18000, jailTime: 31, description: 'Carrying a loaded firearm in public without a license or in prohibited areas.' },
  { id: '83', name: 'Possession of an Assault Weapon', pcCode: 'PC 30605', subtitle: 'Possession of an Assault Weapon', class: 'Felony', fine: 16000, jailTime: 34, description: 'Owning, selling, or manufacturing firearms classified as assault weapons.' },
  { id: '84', name: 'Brandishing a Firearm', pcCode: 'PC 417', subtitle: 'Brandishing a Firearm', class: 'Misdemeanor', fine: 12000, jailTime: 14, description: 'Displaying a firearm in a rudem angry, or threatening manner.' },
  { id: '85', name: 'Criminal Threats', pcCode: 'PC 422', subtitle: 'Criminal Threats', class: 'Felony', fine: 23000, jailTime: 33, description: 'Threatening to kill or harm another, causing sustained fear and demonstrating intent.' },
  { id: '86', name: 'Stalking', pcCode: 'PC 646.9', subtitle: 'Stalking', class: 'Misdemeanor', fine: 11000, jailTime: 15, description: 'Willful and repeated harassment or threats causing credible fear of safety.' },
  { id: '87', name: 'Attempted Crime', pcCode: 'PC 664', subtitle: 'Attempted Crime', class: 'Felony', fine: 30000, jailTime: 38, description: 'The deliberate but unsuccessful attempt to commit a crime.' },
  
  // Title 5: Crimes Against Public Decency and Good Morals
  { id: '88', name: 'Prostitution', pcCode: 'PC 647', subtitle: 'Prostitution', class: 'Misdemeanor', fine: 12400, jailTime: 20, description: 'Engaging in or soliciting sexual acts in exchange for money or other compensation' },
  { id: '89', name: 'Disruption of Religious Assembly', pcCode: 'PC 302', subtitle: 'Disruption of Religious Assembly', class: 'Misdemeanor', fine: 13900, jailTime: 14, description: 'Willfully disturbing or interrupting a religious meeting, ceremony, or worship service through loud or unreasonable behavior.' },
  { id: '90', name: 'Loitering', pcCode: 'PC 647.1', subtitle: 'Loitering', class: 'Misdemeanor', fine: 10200, jailTime: 15, description: 'Remaining in a public place with intent to commit prostitution, drug offenses, or other crimes.' },
  { id: '91', name: 'Selling to a Minor', pcCode: 'PC 25658', subtitle: 'Selling to a Minor', class: 'Felony', fine: 30800, jailTime: 37, description: 'Selling or furnishing alcoholic beverages to persons under age 21.' },
  { id: '92', name: 'Indecent Exposure', pcCode: 'PC 314', subtitle: 'Indecent Exposure', class: 'Misdemeanor', fine: 9700, jailTime: 15, description: 'Willfully exposing one\'s genitals in public or in view of others to offend or satisfy sexual desires.' },
  { id: '93', name: 'Illegal Gambling', pcCode: 'PC 330', subtitle: 'Illegal Gambling', class: 'Misdemeanor', fine: 10800, jailTime: 18, description: 'Operating or participating in unlawful games of chance or betting operations' },
  { id: '94', name: 'Pawnbrokering', pcCode: 'PC 21628', subtitle: 'Pawnbrokering', class: 'Misdemeanor', fine: 11600, jailTime: 22, description: 'Operating as a pawnbroker without proper licensing or violating record-keeping equipments.' },
  { id: '95', name: 'Poisoning', pcCode: 'PC 347', subtitle: 'Poisoning', class: 'Felony', fine: 30000, jailTime: 35, description: 'Willfully mingling poison with food, drink, or medicine with intent to injure.' },
  { id: '96', name: 'Elder Abuse', pcCode: 'PC 368', subtitle: 'Elder Abuse', class: 'Felony', fine: 32500, jailTime: 30, description: 'Willfully causing physical or emotional harm, neglect, or financial exploitation of persons aged 65+.' },
  { id: '97', name: 'Unlawful Practice of Law', pcCode: 'PC 5012', subtitle: 'Unlawful Practice of Law', class: 'Misdemeanor', fine: 15000, jailTime: 25, description: 'Representing oneself as a licensed attorney or providing legal services without proper credentials.' },
  { id: '98', name: 'Harboring a Fugitive', pcCode: 'PC 32', subtitle: 'Harboring a Fugitive', class: 'Felony', fine: 33000, jailTime: 38, description: 'Knowingly concealing or aiding a wanted criminal to evade arrest or prosecution.' },
  
  // Title 6: Crimes Against Public Health and Safety
  { id: '99', name: 'Driving on a Railroad', pcCode: 'PC 369', subtitle: 'Driving on a Railroad', class: 'Infraction', fine: 7500, jailTime: 0, description: 'Operating a vehicle on railroad tracks without authorization, interfering with train operations or creating safety hazards.' },
  { id: '100', name: 'Public Nuisance', pcCode: 'PC 372', subtitle: 'Public Nuisance', class: 'Infraction', fine: 4000, jailTime: 0, description: 'Maintaining a condition that unlawfully obstructs or endangers public health/safety in neighborhoods or public spaces.' },
  { id: '101', name: 'Littering', pcCode: 'PC 374', subtitle: 'Littering', class: 'Infraction', fine: 2000, jailTime: 0, description: 'Willfully depositing waste on public/private property without permission (excluding proper receptacles).' },
  { id: '102', name: 'Illegal Dumping of Human Remains', pcCode: 'PC 379', subtitle: 'Illegal Dumping of Human Remains', class: 'Felony', fine: 35000, jailTime: 40, description: 'Unauthorized disposal or concealment of human corpses outside approved burial methods.' },
  { id: '103', name: 'Food and Drugs Poisoning', pcCode: 'PC 382', subtitle: 'Food and Drugs Poisoning', class: 'Felony', fine: 30000, jailTime: 35, description: 'Knowingly contaminating consumable products with harmful substances, endangering public health.' },
  
  // Title 7: Crimes Against the Public Peace
  { id: '104', name: 'Riot', pcCode: 'PC 404', subtitle: 'Riot', class: 'Felony', fine: 30500, jailTime: 35, description: 'Participating in a violent public disturbance involving an immediate danger of injury or property damage by a group of 3+ persons.' },
  { id: '105', name: 'Inciting a Riot', pcCode: 'PC 404.6', subtitle: 'Inciting a Riot', class: 'Misdemeanor', fine: 12500, jailTime: 22, description: 'Urging others to engage in riotous conduct likely to produce imminent lawless action, whether or not violence occurs.' },
  { id: '106', name: 'Unlawful Assembly', pcCode: 'PC 408', subtitle: 'Unlawful Assembly', class: 'Misdemeanor', fine: 10000, jailTime: 16, description: 'An unlawful assembly occurs when two or more people assemble to do an unlawful act, or a lawful act in a violent, boisterous, or tumultous manner.' },
  { id: '107', name: 'Illegal Fighting', pcCode: 'PC 415', subtitle: 'Illegal Fighting', class: 'Misdemeanor', fine: 10900, jailTime: 18, description: 'Engaging in mutual physical combat in a public place that disturbs others, excluding self-defense situations.' },
  { id: '108', name: 'Disturbing the Peace', pcCode: 'PC 415.5', subtitle: 'Disturbing the Peace', class: 'Misdemeanor', fine: 10500, jailTime: 20, description: 'Engaging in fighting loud noise, or offensive words likely to provoke immediate violent reaction in public.' },
  { id: '109', name: 'Hate Crime', pcCode: 'PC 442.6', subtitle: 'Hate Crime', class: 'Misdemeanor', fine: 12500, jailTime: 20, description: 'Willfully interfering with constitutional rights through threats, violence, or property damage motivated by victim\'s protected characteristics.' },
  { id: '110', name: 'Vandalism', pcCode: 'PC 594', subtitle: 'Vandalism', class: 'Misdemeanor', fine: 10200, jailTime: 12, description: 'Maliciously damaging, destroying or defacing of a person\'s property.' },
  { id: '111', name: 'Denying Entry', pcCode: 'PC 602', subtitle: 'Denying Entry', class: 'Infraction', fine: 5000, jailTime: 0, description: 'Wilfully preventing authorized entry to public facilities by locking doors, blocking access, or using physical barriers without lawful authority.' },
  
  // Title 8: Crimes Against Property
  { id: '112', name: 'Arson', pcCode: 'PC 451', subtitle: 'Arson', class: 'Felony', fine: 30000, jailTime: 35, description: 'Willfully and maliciously setting fire to structures, forest land, or property' },
  { id: '113', name: 'Possession of Arson Material', pcCode: 'PC 453', subtitle: 'Possession of Arson Material', class: 'Felony', fine: 30000, jailTime: 35, description: 'Owning or preparing flammable/explosive substances with intent to commit theft or felony.' },
  { id: '114', name: 'Burglary', pcCode: 'PC 459', subtitle: 'Burglary', class: 'Felony', fine: 28500, jailTime: 31, description: 'Entering any structure with intent to commit theft or felony.' },
  { id: '115', name: 'Unlawful Entry into a Vehicle', pcCode: 'PC 465', subtitle: 'Unlawful Entry into a Vehicle', class: 'Misdemeanor', fine: 15000, jailTime: 30, description: 'Breaking into/locking a vehicle with intent to commit theft.' },
  { id: '116', name: 'Possession of Burglary Equipment', pcCode: 'PC 466', subtitle: 'Possession of Burglary Equipment', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Owning tools adapted for breaking/entering with criminal intent.' },
  { id: '117', name: 'Petty Theft', pcCode: 'PC 484 (a)', subtitle: 'Petty Theft', class: 'Misdemeanor', fine: 10500, jailTime: 15, description: 'Stealing property valued less than or equal to 950$ (or any amount of agricultural products).' },
  { id: '118', name: 'Grand Theft', pcCode: 'PC 487', subtitle: 'Grand Theft', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Stealing property valued more than 950$, firearms, or certain animals.' },
  { id: '119', name: 'Grand Theft of a Firearm', pcCode: 'PC 487(2)', subtitle: 'Grand Theft of a Firearm', class: 'Felony', fine: 35000, jailTime: 40, description: 'Stealing any firearm regardless of value.' },
  { id: '120', name: 'Automotive Property Theft', pcCode: 'PC 496.5', subtitle: 'Automotive Property Theft', class: 'Misdemeanor', fine: 0, jailTime: 25, description: 'Receiving/selling stolen vehicle parts with knowledge.' },
  { id: '121', name: 'False Personation', pcCode: 'PC 499', subtitle: 'False Personation', class: 'Misdemeanor', fine: 15000, jailTime: 30, description: 'Impersonating another to cause harm/gain benefit (excluding PC 529).' },
  { id: '122', name: 'Stolen Valor', pcCode: 'PC 532', subtitle: 'Stolen Valor', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Fraudulently claiming military honors/decorations for benefit.' },
  { id: '123', name: 'Possession of Property with Altered Identification', pcCode: 'PC 537', subtitle: 'Possession of Property with Altered Identification', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Owning property with removed/altered serial numbers.' },
  { id: '124', name: 'Insurance Fraud', pcCode: 'PC 550', subtitle: 'Insurance Fraud', class: 'Felony', fine: 28500, jailTime: 31, description: 'Knowingly making false claims to insurers.' },
  { id: '125', name: 'Trespassing', pcCode: 'PC 602(2)', subtitle: 'Trespassing', class: 'Misdemeanor', fine: 26500, jailTime: 30, description: 'Refusing to leave private property after owner request.' },
  { id: '126', name: 'Illegal Signage', pcCode: 'PC 556', subtitle: 'Illegal Signage', class: 'Infraction', fine: 3000, jailTime: 0, description: 'Posting advertisements on utility polies without permission.' },
  { id: '127', name: 'Destruction of Food Containers', pcCode: 'PC 565', subtitle: 'Destruction of Food Containers', class: 'Infraction', fine: 5000, jailTime: 0, description: 'Damaging/contaminating food containers to deceive buyers.' },
  { id: '128', name: 'Unlawful Subleasing of Vehicles', pcCode: 'PC 571', subtitle: 'Unlawful Subleasing of Vehicles', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Fraudulently subleasing vehicles without owner consent.' },
  { id: '129', name: 'Fraudulent Issue of Merchandise Documents', pcCode: 'PC 581', subtitle: 'Fraudulent Issue of Merchandise Documents', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Issuing false bills/receipts for merchandise.' },
  { id: '130', name: 'Destruction of Roadways, Traffic Devices, or Signage', pcCode: 'PC 594.1', subtitle: 'Destruction of Roadways, Traffic Devices, or Signage', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Defacing/destryong traffic control devices.' },
  { id: '131', name: 'False Personation and Cheats Identification', pcCode: 'PC 3004', subtitle: 'False Personation and Cheats Identification', class: 'Misdemeanor', fine: 15000, jailTime: 30, description: 'Manufacturing/selling fake government IDs.' },
  { id: '132', name: 'False Reporting', pcCode: 'PC 148.5', subtitle: 'False Reporting', class: 'Infraction', fine: 5000, jailTime: 0, description: 'Making false police reports about crimes.' },
  { id: '133', name: 'Grand Theft Auto', pcCode: 'PC 487d', subtitle: 'Grand Theft Auto', class: 'Felony', fine: 30000, jailTime: 35, description: 'Stealing a vehicle (regardless of value).' },
  { id: '134', name: 'Shoplifting', pcCode: 'PC 459.5', subtitle: 'Shoplifting', class: 'Misdemeanor', fine: 13500, jailTime: 25, description: 'Entering open business during hours with intent to steal less than or equal 950$.' },
  
  // Title 9: Drug/Narcotics Offenses
  { id: '135', name: 'Possession of Narcotics', pcCode: '900.01', subtitle: 'Possession of Narcotics', class: 'Felony', fine: 30000, jailTime: 38, description: 'Unlawful possession of controlled substances such as cocaine, heroin, methamphetamine, etc. without a valid prescription.' },
  { id: '136', name: 'Possession of Drugs with Intent to Distribute', pcCode: '900.02', subtitle: 'Possession of Drugs with Intent to Distribute', class: 'Felony', fine: 28000, jailTime: 35, description: 'Possessing controlled substances in quantities or with circumstances that suggest intent to sell or distribute' },
  { id: '137', name: 'Drug Trafficking', pcCode: '900.03', subtitle: 'Drug Trafficking', class: 'Felony', fine: 0, jailTime: 0, description: '' }
];

export default function FineCalculator() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCharges, setSelectedCharges] = useState<Charge[]>([]);
  const [relatedCase, setRelatedCase] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredCharges = useMemo(() => {
    if (!searchTerm) return [];
    return mockCharges.filter(charge =>
      charge.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      charge.pcCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      charge.subtitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      charge.class.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const toggleCharge = (charge: Charge) => {
    setSelectedCharges(prev => {
      const exists = prev.find(c => c.id === charge.id);
      if (exists) {
        return prev.filter(c => c.id !== charge.id);
      } else {
        return [...prev, charge];
      }
    });
  };

  const removeCharge = (chargeId: string) => {
    setSelectedCharges(prev => prev.filter(c => c.id !== chargeId));
  };

  const totalFines = selectedCharges.reduce((sum, charge) => sum + charge.fine, 0);
  const totalJailTime = selectedCharges.reduce((sum, charge) => sum + charge.jailTime, 0);

  const generateDiscordTemplate = () => {
    const chargesList = selectedCharges.map(charge => `- ${charge.name}`).join('\n');
    
    return `***Related case:***
${relatedCase || '-'}
***Charges: ***
${chargesList || '-'}
***Penalty Fines:***
- $${totalFines.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
***Jail Time:***
- ${totalJailTime} Months`;
  };

  const copyToClipboard = async () => {
    const template = generateDiscordTemplate();
    try {
      await navigator.clipboard.writeText(template);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getCategoryColor = (chargeClass: string) => {
    const colors: Record<string, string> = {
      'Felony': 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300',
      'Misdemeanor': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300',
      'Infraction': 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300',
      'Judicial Discretion': 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300',
    };
    
    // Apply class-based styling
    let baseColor = colors[chargeClass] || 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    
    if (chargeClass === 'Felony') {
      return baseColor.replace('text-', 'text-red-900 dark:text-red-200 ').replace('bg-', 'bg-red-200 dark:bg-red-950/30 ');
    } else if (chargeClass === 'Misdemeanor') {
      return baseColor.replace('text-', 'text-yellow-900 dark:text-yellow-200 ').replace('bg-', 'bg-yellow-200 dark:bg-yellow-950/30 ');
    } else if (chargeClass === 'Infraction') {
      return baseColor.replace('text-', 'text-blue-900 dark:text-blue-200 ').replace('bg-', 'bg-blue-200 dark:bg-blue-950/30 ');
    } else if (chargeClass === 'Judicial Discretion') {
      return baseColor.replace('text-', 'text-purple-900 dark:text-purple-200 ').replace('bg-', 'bg-purple-200 dark:bg-purple-950/30 ');
    }
    
    return baseColor;
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-between items-center mb-4">
            <div className="flex-1" />
            <div className="flex justify-center">
              <img 
                src="https://media.discordapp.net/attachments/1405820517373575208/1429123292245131324/image.png?ex=69207fc8&is=691f2e48&hm=054200b2bb530b0604b034468095fdde4307a87709e303d4669c1473b125e053&=&format=webp&quality=lossless&width=768&height=768"
                alt="Sheriff Department Logo"
                className="w-24 h-24"
              />
            </div>
            <div className="flex-1 flex justify-end">
              <ThemeToggle />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Sheriff Department Fine Calculator
          </h1>
          <p className="text-muted-foreground">
            Calculate fines and jail time for criminal charges
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Search and Charges Selection */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Search Charges
                </CardTitle>
                <CardDescription>
                  Search for charges by name or category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Input
                  placeholder="Search charges (e.g., Robbery, Drug, Violent)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
                
                {/* Search Results */}
                {searchTerm && (
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">
                      Search Results ({filteredCharges.length})
                    </h3>
                    <ScrollArea className="h-64 rounded-md border">
                      <div className="p-3 space-y-2">
                        {filteredCharges.length === 0 ? (
                          <p className="text-muted-foreground text-center py-4">
                            No charges found
                          </p>
                        ) : (
                          filteredCharges.map((charge) => (
                            <div
                              key={charge.id}
                              onClick={() => toggleCharge(charge)}
                              className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                                selectedCharges.find(c => c.id === charge.id)
                                  ? 'bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800'
                                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-medium text-foreground">
                                      {charge.name}
                                    </h4>
                                    <div className="flex items-center gap-2">
                                      <Badge className={getCategoryColor(charge.class)}>
                                        {charge.class}
                                      </Badge>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      <DollarSign className="w-3 h-3" />
                                      ${charge.fine.toLocaleString()}
                                    </span>
                                    <span className="flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      {charge.jailTime} months
                                    </span>
                                  </div>
                                </div>
                                <div className="w-5 h-5 rounded border-2 border-border flex items-center justify-center">
                                  {selectedCharges.find(c => c.id === charge.id) && (
                                    <div className="w-3 h-3 bg-primary rounded-sm" />
                                  )}
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* All Charges */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="w-5 h-5" />
                  All Available Charges
                </CardTitle>
                <CardDescription>
                  Click to select multiple charges
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64 rounded-md border">
                  <div className="p-3 space-y-2">
                    {mockCharges.map((charge) => (
                      <div
                        key={charge.id}
                        onClick={() => toggleCharge(charge)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                          selectedCharges.find(c => c.id === charge.id)
                            ? 'bg-primary/10 border-primary/20'
                            : 'bg-card border-border'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-foreground">
                                {charge.name}
                              </h4>
                              <Badge className={getCategoryColor(charge.class)}>
                                {charge.class}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <DollarSign className="w-3 h-3" />
                                ${charge.fine.toLocaleString()}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {charge.jailTime} months
                              </span>
                            </div>
                          </div>
                          <div className="w-5 h-5 rounded border-2 border-border flex items-center justify-center">
                            {selectedCharges.find(c => c.id === charge.id) && (
                              <div className="w-3 h-3 bg-primary rounded-sm" />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Selected Charges */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Selected Charges ({selectedCharges.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedCharges.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    No charges selected
                  </p>
                ) : (
                  <div className="space-y-2">
                    {selectedCharges.map((charge) => (
                      <div
                        key={charge.id}
                        className="flex items-center justify-between p-2 bg-muted rounded-lg"
                      >
                        <div className="flex-1">
                          <h4 className="font-medium text-sm text-foreground">
                            {charge.name}
                          </h4>
                          <p className="text-xs text-muted-foreground">
                            ${charge.fine.toLocaleString()} • {charge.jailTime} months
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeCharge(charge.id)}
                          className="h-6 w-6 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Related Case
                  </label>
                  <Input
                    placeholder="Enter the discord link of related case"
                    value={relatedCase}
                    onChange={(e) => setRelatedCase(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-muted-foreground">
                      Total Fines:
                    </span>
                    <span className="text-lg font-bold text-green-600 dark:text-green-400">
                      ${totalFines.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-muted-foreground">
                      Total Jail Time:
                    </span>
                    <span className="text-lg font-bold text-orange-600 dark:text-orange-400">
                      {totalJailTime} Months
                    </span>
                  </div>
                </div>
                
                <Button
                  onClick={copyToClipboard}
                  disabled={selectedCharges.length === 0}
                  className="w-full"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Discord Template
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Preview */}
            {selectedCharges.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Discord Template Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-muted p-3 rounded-lg overflow-x-auto whitespace-pre-wrap">
                    {generateDiscordTemplate()}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}